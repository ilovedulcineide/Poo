/**
 * 
 */
/**
 * 
 */
module lab3 {
}