package tarefa1;

public class TestaPessoa {
   public static void main(String[] args) {
	   Pessoa p1 = new Pessoa ("123", "João");
	   Pessoa p2 = new Pessoa ("111", "Maria");
	   
	   
	   System.out.println(" dados da primeira pessoa");
	   System.out.println("	CPF: "+ p1.getCpf());
	   System.out.println("Nome:" + p1.getNome());

	   System.out.println("                         ");

	   
	   System.out.println(" dados da segunda pessoa");
	   System.out.println("CPF" + p2.getCpf());
	   System.out.println("Nome:"+ p2.getNome());
  
   }
}
